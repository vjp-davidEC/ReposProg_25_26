/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1ampliacioni;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio1AmpliacionI {
    
    /* Pide y retorna la opción del menú */
    public static int pedirOpcionMenu(){
        Scanner teclado = new Scanner(System.in);
        int opc;
        System.out.print("   Opcion: ");
        try{
            opc = teclado.nextInt();
        }
        catch(InputMismatchException e){
            opc = 0;
            teclado.next();  //Limpiamos el buffer
        }
        return opc;
    }

    /* Pide y retorna el nombre introducido por el usuario */
    public static String pedirNombre(String mensaje){
        Scanner teclado = new Scanner(System.in);
        String nombre;
        System.out.print(mensaje);
        nombre = teclado.nextLine();
        return nombre;
    }

    /* Pide (si/no) si la Actividad pertenece a toda la familia y, en función del valor introducido, 
       retornamos True o False. */
    public static boolean pedirTodaFamilia(){
        Scanner teclado = new Scanner(System.in);
        String resp;
        System.out.print("¿Actividad para toda la familia? (si/no)");
        resp = teclado.nextLine();
        if  (resp.equalsIgnoreCase("SI")){
            return true;
        }
        else{
            return false;
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vivienda vivienda = new Vivienda("C/ UnaVivienda");  //Creamos una Vivienda
        Actividad aux;
        String nombre, tipo;
        boolean todaFamilia;
        int opc;
        do{
            System.out.println("1. Añadir actividad ");
            System.out.println("2. Mostrar actividades");
            System.out.println("3. Mostrar actividades para toda la familia");
            System.out.println("4. Mostrar actividades por tipo");
            System.out.println("5. Mostrar número de actividades");
            System.out.println("6. Salir");
            opc = pedirOpcionMenu();
            switch(opc){
                case 1:
                    nombre = pedirNombre("Nombre Actividad: ");
                    tipo = pedirNombre("Tipo Actividad: ");
                    todaFamilia = pedirTodaFamilia();
                    //Cremoa la nueva Actividad a partir de los datos que hemos pedido
                    aux = new Actividad(nombre, tipo, todaFamilia);
                    //Insertamos la nueva actividad en la vivienda
                    vivienda.insActividad(aux);
                    break;
                case 2:
                    vivienda.mostrarVivienda();
                    break;
                case 3:
                    vivienda.mostrarActividadesTodaFamilia();
                    break;
                case 4:
                    tipo = pedirNombre("Tipo Actividad: ");
                    vivienda.mostrarActividadesPorTipo(tipo);
                    break;
                case 5:
                    System.out.println("Ahora mismo hay "+vivienda.getNumeroActividades()+" actividades para la vivienda");
                    break;
                case 6:
                    System.out.println("¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }
        }while(opc != 6);
    }
    
}
