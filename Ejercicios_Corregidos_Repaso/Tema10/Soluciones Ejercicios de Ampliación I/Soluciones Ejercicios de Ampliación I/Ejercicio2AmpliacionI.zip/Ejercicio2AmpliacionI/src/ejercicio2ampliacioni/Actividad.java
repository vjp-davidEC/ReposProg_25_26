/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2ampliacioni;

/**
 *
 * @author Quique Pineda
 */
public class Actividad {
    /*** Atributos ***/
    private String nombre;
    private String tipo;
    private boolean todaFamilia;  //True cuando la actividad sea para toda la familia

    /*** Métodos ***/

    /* Constructor por defecto */
    public Actividad(){
        this.nombre = "";
        this.tipo = "";
        this.todaFamilia = false;
    }
    
    /* Constructor parametrizado */
    public Actividad(String nombre, String tipo, boolean todaFamilia){
        this.nombre = nombre;
        this.tipo = tipo;
        this.todaFamilia = todaFamilia;
    }
    
    /* Retorna el nombre de la Actividad */
    public String getNombre() {
        return this.nombre;
    }

    /* Actualiza el nombre de la Actividad */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /* Retorna el tipo de la Actividad */
    public String getTipo() {
        return this.tipo;
    }

    /* Actualiza el tipo de la Actividad */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    /* Retorna True o False en función de si la Actividad es para toda la familia o no */
    public boolean isTodaFamilia() {
        return todaFamilia;
    }

    /* Actualiza si la Actividad es para toda la familia o no */
    public void setTodaFamilia(boolean todaFamilia) {
        this.todaFamilia = todaFamilia;
    }
    
    /* Muestra las características de la Actividad */
    public void mostrarActividad(){
        System.out.println("    Actividad: "+this.nombre);
        System.out.println("    Tipo: "+this.tipo);
        if  (this.todaFamilia){
            System.out.println("    Toda la familia: SI");
        }
        else{
            System.out.println("    Toda la familia: NO");
        }
    }
}
