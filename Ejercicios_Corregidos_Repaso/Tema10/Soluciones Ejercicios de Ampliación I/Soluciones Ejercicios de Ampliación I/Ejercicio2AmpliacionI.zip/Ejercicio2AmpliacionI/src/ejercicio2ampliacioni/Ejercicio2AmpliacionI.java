/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2ampliacioni;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class Ejercicio2AmpliacionI {
    
    /* Pide y retorna la opción del menú */
    public static int pedirOpcionMenu(){
        Scanner teclado = new Scanner(System.in);
        int opc;
        System.out.print("   Opcion: ");
        try{
            opc = teclado.nextInt();
        }
        catch(InputMismatchException e){
            opc = 0;
            teclado.next();  //Limpiamos el buffer
        }
        return opc;
    }

    /* Pide y retorna el nombre introducido por el usuario */
    public static String pedirNombre(String mensaje){
        Scanner teclado = new Scanner(System.in);
        String nombre;
        System.out.print(mensaje);
        nombre = teclado.nextLine();
        return nombre;
    }

    /* Pide (si/no) si la Actividad pertenece a toda la familia y, en función del valor introducido, 
       retornamos True o False. */
    public static boolean pedirTodaFamilia(){
        Scanner teclado = new Scanner(System.in);
        String resp;
        System.out.print("¿Actividad para toda la familia? (si/no)");
        resp = teclado.nextLine();
        if  (resp.equalsIgnoreCase("SI")){
            return true;
        }
        else{
            return false;
        }
    }

    /* Pide y retorna la posición introducida por el usuario */
    public static int pedirPosicionDeVector(){
        Scanner teclado = new Scanner(System.in);
        int pos;
        System.out.print("Posición del vector: ");
        try{
            pos = teclado.nextInt();
        }
        catch(InputMismatchException e){
            pos = -1;
            teclado.next();  //Limpiamos el buffer
        }
        return pos;
    }
    
    /* Rellena las viviendas sin actividades */
    public static void rellenarViviendas(Vivienda[] vViviendas){
        String direccion;
        for(int i = 0;i < vViviendas.length;i++){
            direccion = pedirNombre("Direccion Vivienda "+(i+1)+": ");
            /* Reservamos memoria para la vivienda situada en la posición
               "i" del vector */
            vViviendas[i] = new Vivienda(direccion);
        }
    }
    
    /* Crea una nueva actividad y la inserta en la vivienda adecuada */
    public static void insertarActividad(Vivienda[] vViviendas){
        int pos;
        String nombre, tipo;
        boolean todaFamilia;
        Actividad aux;
        //Pedimos la posición de la vivienda donde insertar la actividad
        do{
            pos = pedirPosicionDeVector();
        }while(pos == -1);
        //Creamos una nueva Actividad
        nombre = pedirNombre("Nombre Actividad: ");
        tipo = pedirNombre("Tipo Actividad: ");
        todaFamilia = pedirTodaFamilia();
        aux = new Actividad(nombre, tipo, todaFamilia);
        //Insertamos la nueva actividad en la vivienda
        insertarActividadEnVivienda(vViviendas, aux, pos);
    }
    
    /* Inserta la actividad en la vivienda situada en la posición indicada */
    public static void insertarActividadEnVivienda(Vivienda[] vViviendas, Actividad nActividad, int posVivienda){
        try{
            vViviendas[posVivienda].insActividad(nActividad);
        }
        catch(NullPointerException e){
            System.out.println("Imposible insertar en la vivienda");
        }
        catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Imposible insertar en la vivienda");
        }
    }
    
    /* Muestra la información de todas las viviendas del vector */
    public static void mostrarViviendas(Vivienda[] vViviendas){
        for(int i = 0;i < vViviendas.length;i++){
            try{
                vViviendas[i].mostrarVivienda();
            }
            catch(NullPointerException e){
                System.out.println("Error al mostrar vivienda "+i);
            }
        }
    }
    
    /* Muestra las actividades para toda la familia de cada vivienda */
    public static void mostrarActividadesTodaFamilia(Vivienda[] vViviendas){
        for(int i = 0;i < vViviendas.length;i++){
            try{
                vViviendas[i].mostrarActividadesTodaFamiliaDeVivienda();
            }
            catch(NullPointerException e){
                System.out.println("Error al mostrar vivienda "+i);
            }
        }
    }
    
    /* Muestra las actividades para toda la familia de cada vivienda */
    public static void mostrarActividadesPorTipo(Vivienda[] vViviendas, String tipo){
        for(int i = 0;i < vViviendas.length;i++){
            try{
                vViviendas[i].mostrarActividadesPorTipoEnVivienda(tipo);
            }
            catch(NullPointerException e){
                System.out.println("Error al mostrar vivienda "+i);
            }
        }
    }
    
    /* Suma las actividades de cada una de las viviendas y retorna el resultado */
    public static int getTotalActividades(Vivienda[] vViviendas){
        int total = 0;
        for(int i = 0;i < vViviendas.length;i++){
            try{
                total = total + vViviendas[i].getNumeroActividades();
            }
            catch(NullPointerException e){
                System.out.println("Error al acceder a vivienda "+i);
            }
        }
        return total;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declaramos e instanciamos un vector de 3 viviendas
        Vivienda[] vViviendas = new Vivienda[3];
        Actividad aux;
        String nombre, tipo;
        boolean todaFamilia;
        int opc, pos;
        do{
            System.out.println("1. Rellenar viviendas ");
            System.out.println("2. Añadir actividad");
            System.out.println("3. Mostrar viviendas");
            System.out.println("4. Mostrar actividades para toda la familia");
            System.out.println("5. Mostrar actividades por tipo");
            System.out.println("6. Mostrar número de actividades");
            System.out.println("7. Salir");
            opc = pedirOpcionMenu();
            switch(opc){
                case 1:
                    rellenarViviendas(vViviendas);
                    break;
                case 2:
                    insertarActividad(vViviendas);
                    break;
                case 3:
                    mostrarViviendas(vViviendas);
                    break;
                case 4:
                    mostrarActividadesTodaFamilia(vViviendas);
                    break;
                case 5:
                    tipo = pedirNombre("Tipo Actividad: ");
                    mostrarActividadesPorTipo(vViviendas, tipo);
                    break;
                case 6:
                    System.out.println("Ahora mismo hay "+getTotalActividades(vViviendas)+" actividades para las viviendas");
                    break;
                case 7:
                    System.out.println("¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción incorrecta");
            }
        }while(opc != 7);
    }
    
}
