/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2ampliacioni;

import java.util.ArrayList;

/**
 *
 * @author Quique Pineda
 */
public class Vivienda {
    /*** Atributos ***/
    private String direccion;
    private ArrayList<Actividad> lActividades;  //Una vivienda puede tener 1 ó muchas actividades. O, incluso, ninguna

    /*** Métodos ***/

    /* Constructor por defecto */
    public Vivienda() {
        this.direccion = "";
        //Reservamos memoria para el ArrayList.
        this.lActividades = new ArrayList<>();
    }

    /* Constructor parametrizado */
    public Vivienda(String direccion) {
        this.direccion = direccion;
        //Reservamos memoria para el ArrayList.
        this.lActividades = new ArrayList<>();
    }

    /* Retorna la dirección de la Vivienda */
    public String getDireccion() {
        return direccion;
    }

    /* Actualiza la dirección de la Vivienda */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    /* Inserta la Actividad recibida por parámetros en la lista de actividades de la Vivienda */
    public void insActividad(Actividad nActividad){
        this.lActividades.add(nActividad);
    }
    
    /* Muestra la dirección de la Vivienda junto con sus Actividades */
    public void mostrarVivienda(){
        System.out.println("VIVIENDA: "+this.direccion);
        for(int i = 0;i < this.lActividades.size();i++){
            this.lActividades.get(i).mostrarActividad();
        }
    }
    
    /* Muestra la dirección de la Vivienda junto con sus Actividades para toda la familia */
    public void mostrarActividadesTodaFamiliaDeVivienda(){
        System.out.println("VIVIENDA: "+this.direccion);
        for(int i = 0;i < this.lActividades.size();i++){
            if  (this.lActividades.get(i).isTodaFamilia()){
                this.lActividades.get(i).mostrarActividad();
            }
        }
    }
    
    public void mostrarActividadesPorTipoEnVivienda(String tipo){
        //En esta ocasión utilizamos un for-each
        for(Actividad aux:this.lActividades){
            //Si el tipo de actividad recogida es igual al tipo de actividad que estamos buscando
            if  (aux.getTipo().equalsIgnoreCase(tipo)){
                aux.mostrarActividad();
            }
        }
    }
    
    /* Retorna el número de Actividades de la Vivienda */
    public int getNumeroActividades(){
        return this.lActividades.size();
    }
}
