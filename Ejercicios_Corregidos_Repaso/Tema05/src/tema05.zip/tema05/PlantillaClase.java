
package tema05;

/*
    Las clases son "plantillas" que nos permiten definir
    las características y comportamientos de objetos del mundo real
    para luego representarlos en nuestros programas.

    Todas las clases siguen la misma estructura:
*/

/**
 *
 * @author d3stroya
 */
public class PlantillaClase {
    // ATRIBUTOS
    
    // CONSTRUCTORES
    
    // GETTERS Y SETTERS
    
    // MÉTODOS
    
    // TO STRING
    
}
