
package tema05.ejercicios;

/**
 *
 * @author d3stroya
 */
public class Ejercicio13 {
    /**
     * Método main
     * @param args 
     */
    public static void main(String[] args) {
        // Creo el objeto saludo e imprimo su frase 5 veces
        Saludo saludo = new Saludo("Hola, ¿qué tal?");
        saludo.saludar(5);
    }
}
